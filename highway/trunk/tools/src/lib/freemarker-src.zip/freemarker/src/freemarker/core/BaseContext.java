/*
 * Copyright (c) 2006 The Visigoth Software Society. All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowledgement:
 *       "This product includes software developed by the
 *        Visigoth Software Society (http://www.visigoths.org/)."
 *    Alternately, this acknowledgement may appear in the software itself,
 *    if and wherever such third-party acknowledgements normally appear.
 *
 * 4. Neither the name "FreeMarker", "Visigoth", nor any of the names of the 
 *    project contributors may be used to endorse or promote products derived
 *    from this software without prior written permission. For written
 *    permission, please contact visigoths@visigoths.org.
 *
 * 5. Products derived from this software may not be called "FreeMarker" or "Visigoth"
 *    nor may "FreeMarker" or "Visigoth" appear in their names
 *    without prior written permission of the Visigoth Software Society.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE VISIGOTH SOFTWARE SOCIETY OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Visigoth Software Society. For more
 * information on the Visigoth Software Society, please see
 * http://www.visigoths.org/
 */

package freemarker.core;

import java.util.*;

import freemarker.template.*;

abstract public class BaseContext implements Scope {
	
	private HashMap<String,TemplateModel> variables = new HashMap<String,TemplateModel>();
	private final Scope enclosingScope;
	
	BaseContext(Scope enclosingScope) {
		this.enclosingScope = enclosingScope;
		if (enclosingScope == null) throw new IllegalArgumentException();
	}
	
	public final Scope getEnclosingScope() {
		return enclosingScope;
	}
	
	public Environment getEnvironment() {
		Scope result = enclosingScope;
		while (!(result instanceof Environment)) {
			result = result.getEnclosingScope();
		}
		return (Environment) result;
	}
	
	public void put(String key, TemplateModel value) {
		variables.put(key, value);
	}
	
	public TemplateModel remove(String key) {
		return (TemplateModel) variables.remove(key);
	}
	
	public TemplateModel get(String key) throws TemplateModelException{
		return variables.get(key);
	}
	
	public final TemplateModel resolveVariable(String key) throws TemplateModelException {
		TemplateModel result = variables.get(key);
		if (result == null) {
			return getEnclosingScope().resolveVariable(key);
		}
		return result;
	}
	
	public boolean definesVariable(String key) {
		return variables.containsKey(key);
	}
	
	public boolean isEmpty() {
		return variables.isEmpty();
	}
	
	public TemplateCollectionModel keys() throws TemplateModelException {
		return new SimpleCollection(variables.keySet(), TRIVIAL_WRAPPER);
/*		
		TemplateCollectionModel fallbackKeys = getEnclosingScope().keys();
		LinkedHashSet<TemplateModel> aggregate = new LinkedHashSet<TemplateModel>();
		for (TemplateModelIterator tmi = fallbackKeys.iterator(); tmi.hasNext();) {
			aggregate.add(tmi.next());
		}
		for (String varname : variables.keySet()) {
			aggregate.add(new SimpleScalar(varname));
		}
		return new SimpleCollection(aggregate, TRIVIAL_WRAPPER);
*/		
	}
	
	public TemplateCollectionModel values() throws TemplateModelException {
		return new SimpleCollection(variables.values(), TRIVIAL_WRAPPER);
/*		
		TemplateCollectionModel fallbackValues = getEnclosingScope().values();
		LinkedHashSet<TemplateModel> aggregate = new LinkedHashSet<TemplateModel>();
		for (TemplateModelIterator tmi = fallbackValues.iterator(); tmi.hasNext();) {
			aggregate.add(tmi.next());
		}
		for (TemplateModel value : variables.values()) {
			aggregate.add(value);
		}
		return new SimpleCollection(aggregate, TRIVIAL_WRAPPER);
*/		
	}
	
	
	public int size() throws TemplateModelException {
		return variables.size();
/*		
		Scope enclosingScope = getEnclosingScope();
		int result = enclosingScope.size();
		for (String varname : variables.keySet()) {
			if (enclosingScope.get(varname) != null) 
				++result;
		}
		return result;
*/		
	}
	
	public void clear() {
		variables.clear();
	}
	
	// An object wrapper where everything is known to be either a string or already a TemplateModel
	
	static ObjectWrapper TRIVIAL_WRAPPER = new ObjectWrapper() {
		public TemplateModel wrap(Object obj) {
			if (obj instanceof String) {
				return new SimpleScalar((String) obj);
			}
			return (TemplateModel) obj;
		}
	};
}
