package freemarker.core.helpers;

import freemarker.core.ast.*;

import java.lang.reflect.*;
import java.util.*;
import freemarker.template.utility.StringUtil;

/**
 * Object that outputs FTL tree nodes in a canonical syntax.
 * The idea is that various pretty printers could override key methods
 * here to get a custom dump of an FTL file.
 * @author Jonathan Revusky
 */

public class DefaultTreeDumper {
	
	private String OPEN_BRACKET = "<";
	private String CLOSE_BRACKET = ">";
	
	public DefaultTreeDumper(boolean altSyntax) {
		if (altSyntax) {
			this.OPEN_BRACKET = "[";
			this.CLOSE_BRACKET = "]";
		}
	}
	
	public String render(TemplateNode node) {
		String result = null;
    	try {
    		Class clazz = node.getClass();
    		if (node instanceof BuiltIn) clazz = BuiltIn.class;
        	Method visitMethod = this.getClass().getMethod("render", new Class[] {clazz});
    		result = (String) visitMethod.invoke(this, new Object[] {node});
    	}
    	catch (InvocationTargetException ite) {
    		Throwable cause = ite.getCause();
    		if (cause instanceof RuntimeException) {
    			throw (RuntimeException) cause;
    		}
    	}
    	catch (Exception e) {
    		throw new IllegalArgumentException("There is no routine to render node class " + node.getClass());
    	}
    	return result;
	}
	
	public String render(AddConcatExpression node) {
		return render(node.left) + "+" + render(node.right);
	}
	
	public String render(AndExpression exp) {
		return render(exp.left) + " && " + render(exp.right);
	}
	
	public String render(OrExpression exp) {
		return render(exp.left) + " || " + render(exp.right);
	}
	
	public String render(ArithmeticExpression exp) {
		String opString = null;
		switch (exp.operation) {
		   case ArithmeticExpression.DIVISION : opString = "/";  
		   case ArithmeticExpression.MODULUS : opString = "%"; break;
		   case ArithmeticExpression.MULTIPLICATION : opString = "*"; break;
		   case ArithmeticExpression.SUBSTRACTION : opString = "-"; break;
		}
		return render(exp.left) + opString + render(exp.right);
	}
	
	public String render(AssignmentInstruction node) {
		StringBuffer buf = new StringBuffer();
		buf.append(OPEN_BRACKET);
		buf.append("#");
		switch (node.type) {
			case AssignmentInstruction.GLOBAL : buf.append("global "); break;
			case AssignmentInstruction.LOCAL : buf.append("local "); break;
			case AssignmentInstruction.SET : buf.append("set "); break;
			case AssignmentInstruction.NAMESPACE : buf.append("assign "); break;
		}
		List varnames = node.getVarNames();
		List values = node.getValues();
		for (int i=0; i<varnames.size(); i++) {
			if (i>0) buf.append(", ");
			String varname = (String) varnames.get(i);
			Expression value = (Expression) values.get(i);
			buf.append(varname);
			buf.append("=");
			buf.append(render(value));
		}
		buf.append(CLOSE_BRACKET);
		return buf.toString();
	}
	
	public String render(AttemptBlock node) {
		return OPEN_BRACKET + "#attempt" + CLOSE_BRACKET + render(node.getAttemptBlock()) + render(node.getRecoverBock());
	}
	
	public String render(RecoveryBlock node) {
		TemplateElement content = node.getNestedBlock();
		String contents = content != null ? (String) render(content) : "";
		StringBuffer buf = new StringBuffer();
		buf.append(OPEN_BRACKET);
		buf.append("#recover");
		buf.append(CLOSE_BRACKET);
		buf.append(contents);
		buf.append(OPEN_BRACKET);
		buf.append("/#attempt");
		buf.append(CLOSE_BRACKET);
		return buf.toString();
	}
	
	public String render(Identifier node) {
		return node.name;
	}
	
	public String render(ParentheticalExpression node) {
		return "(" + render(node.nested) + ")";
	}
	
	public String render(BooleanLiteral node) {
		return node.value ? "true" : "false"; 
	}
	
	public String render(NullLiteral node) {
		return "null";
	}
	
	public String render(Dot node) {
		return render(node.target) + "." + node.key;
	}
	
	public String render(Comment node) {
		StringBuffer buf = new StringBuffer();
		buf.append(OPEN_BRACKET);
		buf.append("#--");
		buf.append(node.text);
		buf.append("--");
		buf.append(CLOSE_BRACKET);
		return buf.toString();
	}
	
	public String render(ExistsExpression node) {
		return render(node.exp) + "??";
	}
	
	public String render(DefaultToExpression node) {
		String rhs = node.rhs == null ? "" : (String) render(node.rhs);
		return render(node.lhs) + "!" + rhs;
	}
	
	public String render(NotExpression node) {
		return "!" + render(node.target);
	}
	
	public String render(DollarVariable node) {
		return "${" + render(node.expression) + "}";
	}
	
	public String render(MixedContent node) {
		StringBuffer buf = new StringBuffer();
		List l = node.getNestedElements();
		for (int i=0; i<l.size(); i++) {
			buf.append(render((TemplateNode) l.get(i)));
		}
		return buf.toString();
	}
	
	public String render(DynamicKeyName node) {
		return render(node.target) + "[" + render(node.nameExpression) + "]";
	}
	
	public String render(HashLiteral node) {
		StringBuffer buf = new StringBuffer("{");
		List keys = node.getKeys();
		List values = node.getValues();
		for (int i=0; i<keys.size(); i++) {
			buf.append(render((Expression) keys.get(i)));
			buf.append(" : ");
			buf.append(render((Expression) values.get(i)));
			buf.append(", ");
		}
		buf.append("}");
		return buf.toString();
	}
	
	public String render(NumberLiteral node) {
		return node.value.toString();
	}
	
	public String render(UnaryPlusMinusExpression node) {
		String op = node.isMinus ? "-" : "+";
		return op + render(node);
	}
	
	public String render(MethodCall node) {
		StringBuffer buf = new StringBuffer();
		buf.append(render(node.target));
		buf.append("(");
		List params = node.getParameters();
		for (int i=0; i<params.size(); i++) {
			if (i>0) buf.append(", ");
			buf.append(render((TemplateNode) params.get(i)));
		}
		buf.append(")");
		return buf.toString();
	}
	
	public String render(BlockAssignment node) {
		String varname = StringUtil.quoteStringIfNecessary(node.varName);
		Expression nsExp = node.namespaceExp;
		StringBuffer buf = new StringBuffer();
		buf.append(OPEN_BRACKET);
		String instruction = null;
		switch(node.type) {
			case AssignmentInstruction.GLOBAL : instruction = "#global"; break;
			case AssignmentInstruction.LOCAL : instruction = "#local"; break;
			case AssignmentInstruction.NAMESPACE : instruction = "#assign"; break;
			case AssignmentInstruction.SET : instruction = "#set"; break;
		}
		buf.append(instruction);
		buf.append(" ");
		buf.append(varname);
		if (nsExp != null) {
			buf.append(" in ");
			buf.append(render(nsExp));
		}
		buf.append(CLOSE_BRACKET);
		buf.append(render(node.getNestedBlock()));
		buf.append(OPEN_BRACKET);
		buf.append("/");
		buf.append(instruction);
		buf.append(CLOSE_BRACKET);
		return buf.toString();
	}
	
	public String render(IteratorBlock node) {
		StringBuffer buf = new StringBuffer();
		buf.append(OPEN_BRACKET);
		buf.append("#list ");
		buf.append(render(node.listExpression));
		buf.append(" as ");
		buf.append(node.indexName);
		buf.append(CLOSE_BRACKET);
		buf.append(render(node.getNestedBlock()));
		buf.append(OPEN_BRACKET);
		buf.append("/#list");
		buf.append(CLOSE_BRACKET);
		return buf.toString();
	}
	
	public String render(TextBlock node) {
		String text = node.getText();
		if (!node.unparsed) {
			return text;
		}
		StringBuffer buf = new StringBuffer();
		buf.append(OPEN_BRACKET);
		buf.append("#noparse");
		buf.append(CLOSE_BRACKET);
		buf.append(text);
		buf.append(OPEN_BRACKET);
		buf.append("/#noparse");
		buf.append(CLOSE_BRACKET);
		return buf.toString();
	}
	
	public String render(StringLiteral node) {
		return "\"" + StringUtil.FTLStringLiteralEnc(node.value) + "\"";
	}
	
	public String render(StopInstruction node) {
		StringBuffer buf = new StringBuffer();
		buf.append(OPEN_BRACKET);
		buf.append("#stop");
		if (node.message != null) {
			buf.append(" ");
			buf.append(render(node.message));
		}
		buf.append(CLOSE_BRACKET);
		return buf.toString();
	}
	
	public String render(ReturnInstruction node) {
		StringBuffer buf = new StringBuffer();
		buf.append(OPEN_BRACKET);
		buf.append("#return");
		if (node.returnExp != null) {
			buf.append(" ");
			buf.append(render(node.returnExp));
		}
		buf.append(CLOSE_BRACKET);
		return buf.toString();
	}
	
	public String render(ComparisonExpression node) {
		StringBuffer buf = new StringBuffer();
		buf.append(render(node.left));
		boolean usingAltSyntax = CLOSE_BRACKET.equals("]");
		switch(node.operation) {
			case ComparisonExpression.EQUALS : buf.append(" = "); break;
			case ComparisonExpression.GREATER_THAN :
				if (usingAltSyntax) {
					buf.append(">");
				} else {
					buf.append("gt");
				}
				break;
			case ComparisonExpression.GREATER_THAN_EQUALS :
				if (usingAltSyntax) {
					buf.append(">=");
				}
				else {
					buf.append(" gte ");
				}
				break;
			case ComparisonExpression.LESS_THAN :
				buf.append("<");
				break;
			case ComparisonExpression.LESS_THAN_EQUALS :
				buf.append("<=");
				break;
		}
		buf.append(render(node.right));
		return buf.toString();
	}
	
	public String render(NoEscapeBlock node) {
		StringBuffer buf = new StringBuffer();
		buf.append(OPEN_BRACKET);
		buf.append("#noescape");
		buf.append(CLOSE_BRACKET);
		buf.append(render(node.getNestedBlock()));
		buf.append(OPEN_BRACKET);
		buf.append("/#noescape");
		buf.append(CLOSE_BRACKET);
		return buf.toString();
	}
	
	public String render(CompressedBlock node) {
		StringBuffer buf = new StringBuffer();
		buf.append(OPEN_BRACKET);
		buf.append("#compress");
		buf.append(render(node.getNestedBlock()));
		buf.append(OPEN_BRACKET);
		buf.append("/#compress");
		buf.append(CLOSE_BRACKET);
		return buf.toString();
	}
	
	public String render(ListLiteral node) {
		StringBuffer buf = new StringBuffer();
		buf.append("[");
		List elements = node.getElements();
		for (int i=0; i<elements.size(); i++) {
			if (i>0) {
				buf.append(", ");
			}
			buf.append(render((TemplateNode) elements.get(i)));
		}
		buf.append("]");
		return buf.toString();
	}
	
	public String render(TransformBlock node) {
		StringBuffer buf = new StringBuffer();
		buf.append(OPEN_BRACKET);
		buf.append("#transform ");
		buf.append(render(node.transformExpression));
		Map args = node.getArgs();
		for (Iterator it = args.entrySet().iterator(); it.hasNext();) {
			Map.Entry entry = (Map.Entry) it.next();
			String varname = (String) entry.getKey();
			varname = StringUtil.quoteStringIfNecessary(varname);
			Expression value = (Expression) entry.getValue();
			buf.append(" ");
			buf.append(varname);
			buf.append("=");
			buf.append(render(value));
		}
		buf.append(CLOSE_BRACKET);
		TemplateElement nestedBlock = node.getNestedBlock();
		if (nestedBlock != null) {
			buf.append(render(nestedBlock));
		}
		buf.append(OPEN_BRACKET);
		buf.append("/#transform");
		buf.append(CLOSE_BRACKET);
		return buf.toString();
	}
	
	public String render(NumericalOutput node) {
		StringBuffer buf = new StringBuffer();
		buf.append("#{");
		buf.append(render(node.expression));
		if (node.hasFormat) {
			buf.append(" ; ");
			buf.append("m");
			buf.append(node.minFracDigits);
			buf.append("M");
			buf.append(node.maxFracDigits);
		}
		buf.append("}");
		return buf.toString();
	}
	
	public String render(Range node) {
		StringBuffer buf = new StringBuffer();
		buf.append(render(node.left));
		buf.append("..");
		if (node.right != null) {
			buf.append(render(node.right));
		}
		return buf.toString();
	}
	
	public String render(BreakInstruction node) {
		return OPEN_BRACKET + "#break" + CLOSE_BRACKET; 
	}
	
	public String render(FlushInstruction node) {
		return OPEN_BRACKET + "#flush" + CLOSE_BRACKET;
	}
	
	public String render(BuiltinVariable node) {
		return "." + node.name;
	}
	
	public String render(RecurseNode node) {
		StringBuffer buf = new StringBuffer(); 
		buf.append(OPEN_BRACKET);
		buf.append("#recurse ");
		buf.append(render(node.targetNode));
		if (node.namespaces != null) {
			buf.append(" using ");
			buf.append(render(node.namespaces));
		}
		buf.append(CLOSE_BRACKET);
		return buf.toString();
	}
	
	public String render(BuiltIn node) {
		return render(node.getTarget()) + "?" + node.getName();
	}
	
	public String render(TrimInstruction node) {
		StringBuffer buf = new StringBuffer();
		buf.append(OPEN_BRACKET);
		if (node.left && node.right) {
			buf.append("#t");
		}
		else if (node.left) {
			buf.append("#lt");
		}
		else if (node.right) {
			buf.append("#rt");
		}
		else {
			buf.append("#nt");
		}
		buf.append(CLOSE_BRACKET);
		return buf.toString();
	}
	
	public String render(BodyInstruction node) {
		StringBuffer buf = new StringBuffer();
		buf.append(OPEN_BRACKET);
		buf.append("#nested");
		List params = node.getBodyParameters();
		if (params != null && params.size() >0) {
			buf.append(" ");
			for (int i=0; i<params.size(); i++) {
				if (i>0) buf.append (", ");
				buf.append(render((Expression) params.get(i)));
			}
		}
		buf.append(CLOSE_BRACKET);
		return buf.toString();
	}
	
	public String render(LibraryLoad node) {
		StringBuffer buf = new StringBuffer();
		buf.append(OPEN_BRACKET);
		buf.append("#import ");
		buf.append(render(node.templateName));
		buf.append(" as ");
		buf.append(node.namespace);
		buf.append(CLOSE_BRACKET);
		return buf.toString();
	}
	
	public String render(SwitchBlock node) {
		StringBuffer buf = new StringBuffer();
		buf.append(OPEN_BRACKET);
		buf.append("#switch ");
		buf.append(render(node.testExpression));
		buf.append(CLOSE_BRACKET);
		List cases = node.getCases();
		if (cases != null && cases.size() >0) {
			for (int i=0; i<cases.size(); i++) {
				buf.append(render((Case) cases.get(i)));
			}
		}
		buf.append(OPEN_BRACKET);
		buf.append("/#switch");
		buf.append(CLOSE_BRACKET);
		return buf.toString();
	}
	
	public String render(Case node) {
		StringBuffer buf = new StringBuffer();
		buf.append(OPEN_BRACKET);
		if (node.isDefault()) {
			buf.append("#default");
		} else {
			buf.append("#case ");
			buf.append(render(node.expression));
		}
		buf.append(CLOSE_BRACKET);
		buf.append(render(node.getNestedBlock()));
		return buf.toString();
	}
	
	public String render(PropertySetting node) {
		StringBuffer buf = new StringBuffer();
		buf.append(OPEN_BRACKET);
		buf.append("#setting ");
		buf.append(node.key);
		buf.append(" = ");
		buf.append(render(node.value));
		return buf.toString();
	}
	
	public String render(ScopedDirective node) {
		StringBuffer buf = new StringBuffer();
		buf.append(OPEN_BRACKET);
		buf.append("#scoped ");
		Map vars = node.getVariables();
		for (Iterator it = vars.entrySet().iterator(); it.hasNext();) {
			Map.Entry entry = (Map.Entry) it.next();
			String varname = (String) entry.getKey();
			varname = StringUtil.quoteStringIfNecessary(varname);
			Expression exp = (Expression) entry.getValue();
			buf.append(varname);
			if (exp != null) {
				buf.append("=");
				buf.append(render(exp));
			}
			if (it.hasNext()) buf.append(" ");
		}
		buf.append(CLOSE_BRACKET);
		return buf.toString();
	}
	
	public String render(UnifiedCall node) {
		StringBuffer buf = new StringBuffer();
		Expression nodeNameExp = node.getNameExp();
		buf.append(OPEN_BRACKET);
		buf.append("@");
		buf.append(render(nodeNameExp));
		buf.append(" ");
		Map namedArgs = node.getNamedArgs();
		List positionalArgs = node.getPositionalArgs();
		if (positionalArgs != null) {
			for (int i=0; i<positionalArgs.size(); i++) {
				Expression arg = (Expression) positionalArgs.get(i);
				if (i>0) buf.append(", ");
				buf.append(render(arg));
			}
		}
		else if (namedArgs != null) {
			for (Iterator it = namedArgs.entrySet().iterator(); it.hasNext();) {
				Map.Entry entry = (Map.Entry) it.next();
				buf.append(entry.getKey());
				buf.append("=");
				buf.append(render((Expression) entry.getValue()));
				if (it.hasNext()) buf.append(" ");
			}
		}
		List bodyParameters = node.getBodyParameterNames();
		if (bodyParameters != null && bodyParameters.size() >0) {
			buf.append(";");
			for (int i=0; i<bodyParameters.size(); i++) {
				if (i>0) buf.append (", ");
				buf.append(bodyParameters.get(i));
			}
		}
		TemplateElement body = node.getNestedBlock();
		if (body == null) {
			buf.append("/");
			buf.append(CLOSE_BRACKET);
		} else {
			buf.append(CLOSE_BRACKET);
			buf.append(render(body));
			buf.append(OPEN_BRACKET);
			buf.append("/@");
			if (nodeNameExp instanceof Identifier) {
				buf.append(nodeNameExp);
			}
			buf.append(CLOSE_BRACKET);
		}
		return buf.toString();
	}
	
	public String render(Include node) {
		StringBuffer buf = new StringBuffer();
		buf.append(OPEN_BRACKET);
		buf.append("#include ");
		buf.append(render(node.getIncludedTemplateExpression()));
		Expression parseExp = node.getParseExp();
		Expression encodingExp = node.getEncodingExp();
		if (parseExp != null || encodingExp != null) {
			buf.append (" ;");
			if (encodingExp != null) {
				buf.append(" ");
				buf.append("encoding=");
				buf.append(render(encodingExp));
			}
			if (parseExp != null) {
				buf.append(" ");
				buf.append("parse=");
				buf.append(render(parseExp));
			}
		}
		buf.append(CLOSE_BRACKET);
		return buf.toString();
	}
	
	public String render(ConditionalBlock node) {
		StringBuffer buf = new StringBuffer();
		buf.append(OPEN_BRACKET);
		if (node.isFirst) {
			buf.append("#if ");
		}
		else if (node.condition == null) {
			buf.append("#else");
		}
		else {
			buf.append("#elseif ");
		}
		if (node.condition != null) {
			buf.append(render(node.condition));
		}
		buf.append(CLOSE_BRACKET);
		TemplateElement nestedBlock = node.getNestedBlock();
		if (nestedBlock != null) {
			buf.append(render(nestedBlock));
		}
		if (node.isLoneIfBlock()) {
			buf.append(OPEN_BRACKET);
			buf.append("/#if");
			buf.append(CLOSE_BRACKET);
		}
		return buf.toString();
	}
	
	public String render(IfBlock node) {
		List subBlocks = node.getSubBlocks();
		StringBuffer buf = new StringBuffer();
		for (int i=0; i<subBlocks.size(); i++) {
			TemplateElement block = (TemplateElement) subBlocks.get(i);
			buf.append(render(block));
		}
		buf.append(OPEN_BRACKET);
		buf.append("/#if");
		buf.append(CLOSE_BRACKET);
		return buf.toString();
	}
	
	public String render(Macro node) {
		StringBuffer buf = new StringBuffer();
		buf.append(OPEN_BRACKET);
		if (node.isFunction()) {
			buf.append("#function ");
		} else {
			buf.append("#macro ");
		}
		buf.append(node.getName());
		String[] argNames = node.getArgumentNames();
		Map args = node.getArgs();
		if (argNames != null && argNames.length >0) {
			for (int i=0; i<argNames.length; i++) {
				String argname = argNames[i];
				buf.append(" ");
				buf.append(argname);
				Expression defValue = (Expression) args.get(argname);
				if (defValue != null) {
					buf.append("=");
					buf.append(render(defValue));
				}
			}
		}
		if (node.getCatchAll() != null) {
			buf.append(" ");
			buf.append(node.getCatchAll());
			buf.append("...");
		}
		buf.append(CLOSE_BRACKET);
		TemplateElement nestedBlock = node.getNestedBlock();
		if (nestedBlock != null) {
			buf.append(render(nestedBlock));
		}
		buf.append(OPEN_BRACKET);
		if (node.isFunction()) {
			buf.append("/#function");
		} else {
			buf.append("/#macro");
		}
		buf.append(CLOSE_BRACKET);
		return buf.toString();
	}
}
