package freemarker.core.ast;

import java.util.*;
import freemarker.template.*;
import freemarker.core.Environment;
import freemarker.core.Scope;
import freemarker.core.parser.ParseException;


public class ScopedDirective extends TemplateElement {
	
	private LinkedHashMap<String, Expression> vars = new LinkedHashMap<String, Expression>();
	
	// An array list to hang onto 
	private ArrayList<Expression> originalVariables = new ArrayList<Expression>();
	
	public void execute(Environment env) throws TemplateException {
		for (Iterator it = vars.entrySet().iterator(); it.hasNext();) {
			Map.Entry entry = (Map.Entry) it.next();
			String varname = (String) entry.getKey();
			Expression exp = (Expression) entry.getValue();
			Scope scope = env.getCurrentScope();
			if (exp == null) {
				if (scope.get(varname) == null) {
					scope.put(varname, TemplateModel.JAVA_NULL);
				}
			} 
			else {
				scope.put(varname, exp.getAsTemplateModel(env));
			}
		}
	}
	
	public Map getVariables() {
		return Collections.unmodifiableMap(vars);
	}
	
	public void addVar(Expression name, Expression value) {
		String varname = name.toString();
		if (name instanceof StringLiteral) {
			varname = ((StringLiteral) name).getAsString();
		}
		vars.put(varname, value);
		originalVariables.add(name);
	}
	
	public String getDescription() {
		return "declare scoped variables";
	}
	
	public TemplateElement postParseCleanup(boolean stripWhitespace) throws ParseException {
		TemplateElement parent = this.parent;
		if (parent instanceof MixedContent) {
			parent = (TemplateElement) parent.getParent();
		}
		if (parent != null) {
			for (Iterator it = vars.entrySet().iterator(); it.hasNext();) {
				Map.Entry entry = (Map.Entry) it.next();
				String var = (String) entry.getKey();
				parent.declareScopedVariable(var);
			}
		}
		return this;
	}

}
