/*
 * Copyright (c) 2001-2003 The XDoclet team
 * All rights reserved.
 */
package xjavadoc;

/**
 * Describe what this class does
 *
 * @author         Aslak Helles�y
 * @created        19. februar 2002
 * @todo-javadoc   Write javadocs for interface
 */
public interface XConstructor extends XExecutableMember
{
}

