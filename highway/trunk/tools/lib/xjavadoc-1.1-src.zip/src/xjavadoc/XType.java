/*
 * Copyright (c) 2001-2003 The XDoclet team
 * All rights reserved.
 */
package xjavadoc;

/**
 * @created   22. juli 2002
 */
public interface XType extends XProgramElement
{
}
